Run HANDDETECTION.ipynb. It will open the webcam and start recording you Hand signs.

Then open Train IT.exe and enjoy :)









------------------------------

OR if you want to test without webcam
	- pip install keyboard
	- run the dummy_keyboard_control.py file
	- Launch the game.


W/↑, S/↓, A/←, D/→ → right-hand direction
Q/E → left-hand Left/Right
Esc → quit



Thanks :) 
	- xGT Games